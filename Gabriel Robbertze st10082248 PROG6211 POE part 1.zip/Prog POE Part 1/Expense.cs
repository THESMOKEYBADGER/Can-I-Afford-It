﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;


namespace Prog_POE_Part_1
{
    internal class Expense
    {
        // INSTANTIATING VARIABLES AND ARRAYS
        public double monthlyIncome;
        private string[] costsName = { "monthly tax", "groceries","water & lights", "travel ", "phone bills", "other expenses"};
        public double[] costs = new double[6];
        
        // INTRO METHOD FOR ASKING IF USER QWOULD LIKE TO USE THE APPLICAITON
        public void Hello()
        {
            Console.WriteLine("Hello! This is your own private expense calculator...\n");


            Console.WriteLine("Would you like to make a new calculation?\nEnter y/n\n");
            String userChoice = Console.ReadLine();
            
         // IF STATEMENT FOR YES OR NO TO USE APP
            if(userChoice == "y")
            {
                Console.WriteLine("\nHere we GO!");
            }
            else
            {
                Console.WriteLine("Goodbye then");
                System.Environment.Exit(0);
            }
        }

        private double GetDouble(string s)
        {
            double userOutput = 0;
            string userInput = "";
            do
            {
                Write(s);
                userInput = Console.ReadLine();
            } while (!double.TryParse(userInput, out userOutput));
            
            return userOutput;
        }

        // RETRIEVE DATA FOR MONTHLY COSTS
        public void enterInfo()
        {
            for (int i = 0; i < costs.Length; i++)
            {
                costs[i] = GetDouble(string.Format("Enter cost for {0} : ", costsName[i]));
            }
        }
       
        // RETRIEVE USER MONTHLY INCOME AND CONVERT TO DOUBLE + RETURN INCOME
        public double getMonthlyIncome()
        {
            Console.Write("Enter re-enter your gross monthly income: ");
            monthlyIncome = Convert.ToDouble(Console.ReadLine());
            return monthlyIncome;
        }

        public double MonthlyIncome { get => monthlyIncome; set => monthlyIncome = value; }

        // METHOD TO RETURB A THIRD OF USERS MONTHLY INCOME FOR CALCULATIONS
        public double thirdIncome()
        {
            double thirdIncome =  getMonthlyIncome()* 0.3333;
            return thirdIncome;
        }

        // CALCULATE REMAINING MONEY AFTER ALL DEDUCTIONS
        public static void leftOvers(double[] costs, double monthlyIncome)
        {
        // CALLING REPAYMENT
            Accomodation fetch = new Accomodation();
            double leftOvers = monthlyIncome - (costs[0] + costs[1] + costs[2] + costs[3] + costs[4] + costs[5] + fetch.fetchValue());
            Console.WriteLine("You would have R " + leftOvers + " left after all monthly deductions");
            Console.WriteLine("\n Thank you for using home loan calculator :)");
            System.Environment.Exit(0);
        }
    }
}
