﻿using System;

namespace Prog_POE_Part_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Expense retrieveA = new Expense();
            Accomodation retrieveB = new Accomodation();
            retrieveA.Hello();
            retrieveA.getMonthlyIncome();
            retrieveA.enterInfo();
            retrieveB.rentOrBuy();
            Accomodation.getRepayment();
            Expense.leftOvers(retrieveA.costs, retrieveA.monthlyIncome);
    }
    }
}
